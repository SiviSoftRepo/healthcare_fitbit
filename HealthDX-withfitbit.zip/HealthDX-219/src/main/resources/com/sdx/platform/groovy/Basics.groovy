package com.sdx.platform.groovy

import groovy.json.JsonBuilder

public trait Basics {
	
}
