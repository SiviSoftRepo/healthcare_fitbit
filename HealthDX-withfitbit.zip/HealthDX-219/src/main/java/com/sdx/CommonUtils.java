package com.sdx;

public class CommonUtils {
	
	public static Boolean checkRangeLimit(int lowerLimt,int upperLimt,int testResult) {
		Boolean resultLimit =false;
		if(testResult > upperLimt || testResult < lowerLimt ) {
			resultLimit = true;
		}
		
		return resultLimit;
	}

}
