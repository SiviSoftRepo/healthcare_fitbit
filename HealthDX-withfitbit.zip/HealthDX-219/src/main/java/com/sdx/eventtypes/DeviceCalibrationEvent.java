package com.sdx.eventtypes;

import com.sdx.entity.Telemedicine;

public class DeviceCalibrationEvent extends HCBaseEvent {
	
	private Telemedicine subject	= null;

}
