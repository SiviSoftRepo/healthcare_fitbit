

import java.util.function.Consumer;
import java.util.stream.Collectors;

import com.google.common.base.Joiner;
import com.google.common.base.Joiner.MapJoiner;
import com.sdx.platform.config.Memory;

public class TESTER {
	
	public static void main(String[] args) {}

}
