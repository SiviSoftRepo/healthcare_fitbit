package com.sdx.entity;

public interface BaseEntity {
	 String comments="";
}
