package com.sdx.entity;

import java.io.Serializable;

import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "thersold")
public class Thersold implements Serializable, BaseEntity {

	private static final long serialVersionUID = 1L;
	@Id
	public ObjectId _id;

	private String idRep;
	private String name;
	private String bodyTemperature;
	private String bloodPressure;
	private String lowerLimit;
	private String upperLimit;
	private String normal;
	private String systolic;
	private String diastolic;

	public ObjectId get_id() {
		return _id;
	}

	public  void set_id(ObjectId _id) {
		this._id = _id;
	}

	public String getIdRep() {
		return idRep;
	}

	public void setIdRep(String idRep) {
		this.idRep = idRep;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		name = name;
	}

	public String getBodyTemperature() {
		return bodyTemperature;
	}

	public void setBodyTemperature(String bodyTemperature) {
		this.bodyTemperature = bodyTemperature;
	}

	public String getBloodPressure() {
		return bloodPressure;
	}

	public void setBloodPressure(String bloodPressure) {
		this.bloodPressure = bloodPressure;
	}

	public String getLowerLimit() {
		return lowerLimit;
	}

	public void setLowerLimit(String lowerLimit) {
		this.lowerLimit = lowerLimit;
	}

	public String getUpperLimit() {
		return upperLimit;
	}

	public void setUpperLimit(String upperLimit) {
		this.upperLimit = upperLimit;
	}

	public String getNormal() {
		return normal;
	}

	public void setNormal(String normal) {
		normal = normal;
	}

	public String getSystolic() {
		return systolic;
	}

	public void setSystolic(String systolic) {
		this.systolic = systolic;
	}

	public String getDiastolic() {
		return diastolic;
	}

	public void setDiastolic(String diastolic) {
		this.diastolic = diastolic;
	}

	public String toString() {
		StringBuffer sb = new StringBuffer();
		sb.append(idRep);
		sb.append("|");
		sb.append(name);
		sb.append("|");
		sb.append(bodyTemperature);
		sb.append("|");
		sb.append(bloodPressure);
		sb.append("|");
		sb.append(lowerLimit);
		sb.append("|");
		sb.append(upperLimit);
		sb.append("|");
		sb.append(normal);
		sb.append("|");
		sb.append(systolic);
		sb.append("|");
		sb.append(diastolic);
		return sb.toString();
	}

}
