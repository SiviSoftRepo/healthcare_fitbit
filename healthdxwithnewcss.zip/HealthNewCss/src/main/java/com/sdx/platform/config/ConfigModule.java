package com.sdx.platform.config;

public enum ConfigModule {
	
	GENERAL, USER, DEPARTMENT, MISC, REALTIME;

}
