package com.sdx.platform.config;

import java.util.LinkedHashMap;
import java.util.concurrent.ConcurrentHashMap;

import com.mongodb.ConnectionString;
import com.mongodb.MongoClientSettings;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoDatabase;

import groovy.lang.GroovyObject;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

@Getter
@Slf4j
public class Memory {

	private static MongoClient mongoClient = null;
	private static MongoDatabase sdxBaseDB = null;

	static {
		/*
		 * log.info("*************** KICK Start MEMORY ******************");
		 * ConnectionString connString = new
		 * ConnectionString("mongodb://localhost:27017"); MongoClientSettings settings =
		 * MongoClientSettings.builder().applyConnectionString(connString).retryWrites(
		 * true) .build();
		 * 
		 * mongoClient = MongoClients.create(settings); sdxBaseDB =
		 * Memory.getMongoClient().getDatabase("test"); log.info("Built MongoClient " +
		 * mongoClient);
		 */
	}
	private static ConcurrentHashMap<String, Object> appProperties = new ConcurrentHashMap<>();

	private static LinkedHashMap<String, String> extensionsContent = new LinkedHashMap<>();

	private static LinkedHashMap<String, GroovyObject> extensionObjects = new LinkedHashMap<>();
	private static ConcurrentHashMap<String, GroovyObject> groovyObjects = new ConcurrentHashMap<>();
	private static ConcurrentHashMap<String, String> groovyContent = new ConcurrentHashMap<>();

	public void add2AppProperties(String pKey, Object pValue) {
		appProperties.put(pKey, pValue);
	}

	public static ConcurrentHashMap<String, Object> getAppProperties() {
		if (appProperties == null) {
			appProperties = new ConcurrentHashMap<String, Object>();
		}
		return appProperties;
	}

	public static void setAppProperties(ConcurrentHashMap<String, Object> appProperties) {
		Memory.appProperties = appProperties;
	}

	public static LinkedHashMap<String, String> getExtensionsContent() {
		return extensionsContent;
	}

	public static void setExtensionsContent(LinkedHashMap<String, String> extensionsContent) {
		Memory.extensionsContent = extensionsContent;
	}

	public static LinkedHashMap<String, GroovyObject> getExtensionObjects() {
		return extensionObjects;
	}

	public static void setExtensionObjects(LinkedHashMap<String, GroovyObject> extensionObjects) {
		Memory.extensionObjects = extensionObjects;
	}

	public static void init() {
		log.info("Initializing the SDX Memory");
	}

	public static MongoClient getMongoClient() {
		return mongoClient;
	}

	public static void setMongoClient(MongoClient mongoClient) {
		Memory.mongoClient = mongoClient;
	}

	public static MongoDatabase getSdxBaseDB() {
		return sdxBaseDB;
	}

	public static void setSdxBaseDB(MongoDatabase sdxBaseDB) {
		Memory.sdxBaseDB = sdxBaseDB;
	}

	public static ConcurrentHashMap<String, GroovyObject> getGroovyObjects() {
		return groovyObjects;
	}

	public static void setGroovyObjects(ConcurrentHashMap<String, GroovyObject> groovyObjects) {
		Memory.groovyObjects = groovyObjects;
	}

	public static ConcurrentHashMap<String, String> getGroovyContent() {
		return groovyContent;
	}

	public static void setGroovyContent(ConcurrentHashMap<String, String> groovyContent) {
		Memory.groovyContent = groovyContent;
	}

}
