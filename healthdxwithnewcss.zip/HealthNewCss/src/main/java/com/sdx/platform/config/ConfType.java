package com.sdx.platform.config;

public enum ConfType {
	
	PROPERTY, PORT, PROGRAM, CRON, NUMBER, STRING, BLOB;

}
