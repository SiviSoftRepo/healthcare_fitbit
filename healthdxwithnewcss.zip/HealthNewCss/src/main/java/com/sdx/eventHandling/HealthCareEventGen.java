package com.sdx.eventHandling;

import org.json.JSONObject;

public class HealthCareEventGen {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub

		//for (int i = 0; i < 23; i++) {

		ServiceNowSim.producerTemplate = ServiceNowSim.camelContext.createProducerTemplate();
		ServiceNowSim.producerTemplate.requestBodyAndHeader(SedaEventPush.SEDA_START_ROUTE,
					buildPerformancePayload(), "Event", "HealthCareEvent");
		//}
		// RunSedaApp.buildEvent(buildPerformancePayload());
	}

	public static JSONObject buildPerformancePayload() throws Exception{
		JSONObject payloadJson = new JSONObject();
		payloadJson.put("short_description", "Patient Fallen off the bed");
		payloadJson.put("description", "Patient Fallen off the bed at the time 12.00Pm");
		payloadJson.put("impact", "1");
		payloadJson.put("urgency", "1");
		payloadJson.put("assignment_group", "Patient Health");
		payloadJson.put("caller_id", "ServiceDX ServiceDX");
		System.out.println("payloadJson :::::::::::::" + payloadJson);
		return payloadJson;

	}
	
	
	public static JSONObject buildPatientDiagoniseEvent(String patient,String diagnosis,String vital,String testResult) throws Exception{
		JSONObject payloadJson = new JSONObject();
		payloadJson.put("short_description",diagnosis);
		payloadJson.put("description", "Patient  " +patient+"  "+ diagnosis +"ranges" +testResult);
		payloadJson.put("impact", "1");
		payloadJson.put("urgency", "1");
		payloadJson.put("assignment_group", "Patient Health");
		payloadJson.put("caller_id", "ServiceDX ServiceDX");
		System.out.println("payloadJson :::::::::::::" + payloadJson);
		ServiceNowSim.producerTemplate = ServiceNowSim.camelContext.createProducerTemplate();
		ServiceNowSim.producerTemplate.requestBodyAndHeader(SedaEventPush.SEDA_START_ROUTE,
					buildPerformancePayload(), "Event", "HealthCareEvent");
		return payloadJson;

	}


}
