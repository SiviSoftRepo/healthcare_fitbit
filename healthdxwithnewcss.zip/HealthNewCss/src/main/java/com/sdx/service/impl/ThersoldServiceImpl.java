package com.sdx.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.sdx.entity.BaseEntity;
import com.sdx.entity.Diagnosis;
import com.sdx.entity.Doctor;
import com.sdx.entity.HomeCare;
import com.sdx.entity.Thersold;
import com.sdx.repository.HomeCareRepository;
import com.sdx.repository.ThersoldRepository;
import com.sdx.service.BaseEntityService;

@Component
@Service
public class ThersoldServiceImpl implements BaseEntityService {

	@Autowired
	private ThersoldRepository thersoldRepository;

	@Override
	public BaseEntity findById(String id) {

		return this.thersoldRepository.findById(id).get();
	}

	@Override
	public List<BaseEntity> findAll() {
		List<BaseEntity> thres = new ArrayList<>();
		thersoldRepository.findAll().forEach(threshold -> {
			threshold.setIdRep(threshold._id.toString());
			thres.add(threshold);
			System.out.println("FindAll Medic::" + thres);
			
		});
		return thres;
	}
	
	public Thersold getById(String id) {
		Thersold thersold = thersoldRepository.findById(id).orElse(null);
		return thersold;
	}

	@Override
	public BaseEntity save(BaseEntity entity) {
		if (entity instanceof Thersold) {
			Thersold thersold = (Thersold) entity;
			return this.thersoldRepository.save(thersold);
		}
		return null;
	}

	public BaseEntity update(ObjectId _id, BaseEntity entity) {
		if (entity instanceof Thersold) {
			Thersold thersold = (Thersold) entity;
			thersold.set_id(_id);
			return this.thersoldRepository.save(thersold);
		}
		return null;
	}
	
	
	public Thersold findByDiseaseName(String diseaseName) {
		// TODO Auto-generated method stub
		Thersold thersold = (Thersold) this.thersoldRepository.findByDiseaseName(diseaseName);
		System.out.println("ID OF Thresold IS:::::::::" + thersold.get_id().toString());
		thersold.setIdRep(thersold.get_id().toString());
		System.out.println("Thresold ::::::::::::" + thersold);
		return thersold;
	}
	
	
	public ArrayList<Object> findAllDiseaseName() {
		ArrayList<Object> disease = new ArrayList<>();
		thersoldRepository.findAll().forEach(thresoldRep -> {
			disease.add(thresoldRep.getName());
		
		System.out.println("DOCTOR SERVICE CLASSS "+disease);

		});
		return disease;
	}

	@Override 
	public void delete(String id) {
		thersoldRepository.deleteById(id);
	}

	

	
}
