
public class ConfigInsert {
	
	public static void main(String[] args) {
		//BasicDBObjectBuilder bulder;
	}

}
