package com.sdx.platform.groovy.extensions

import com.sdx.entity.*
import com.sdx.platform.groovy.Basics
import groovy.transform.ToString

import org.springframework.beans.factory.annotation.Autowired
import org.springframework.context.annotation.ComponentScan
import org.springframework.data.mongodb.core.mapping.Document
import com.sdx.platform.groovy.FieldUtils

import org.springframework.context.annotation.ComponentScan


import com.sdx.entity.BaseEntity
import com.sdx.entity.*

import java.util.*;
import groovy.json.JsonOutput




class PatientExtensions  extends Patient implements Basics {
	
	
	
	
	private boolean updateMode = false;
	
	
	def buildFIO(HashMap dbref) {
		
		println("inside groovyyyyyyyyyyyyyyyyyyyyyyyy:::::::::::::::: " +nurse );
		
		
		ArrayList<Object> doctor = dbref.get("Doctor");
		ArrayList<Object> nurse = dbref.get("Nurse");
		ArrayList<Object> diagnosis = dbref.get("Diagnosis");
		String defaultDoctorName =  dbref.get("defaultDoctorName");
		String defaultDiagnosisName =  dbref.get("defaultDiagnosisName");
		String defaultNurseNameName = dbref.get("defaultNurseNameName");
		String defaultGender = dbref.get("defaultGender");
		String defaultStatus = dbref.get("defaultStatus");
	
		
		
		ArrayList<Object> gender = new ArrayList<Object>();
		gender.add("Male");
		gender.add("Female");
		
		ArrayList<Object> status = new ArrayList<Object>();
		status.add("Critical");
		status.add("Immediated Action Required");
		status.add("Stable");
		status.add("Normal");
		
		
		
		
		//ArrayList<Object> userRolesId = dbref.get("UserRole");
		//Map useridMap  	      	    = FieldUtils.buildTF("idRep","idRep", idRep, false);
		Map nameMap  	       		 = FieldUtils.buildTF("Name","name", name, false);
		Map genderMap           	= FieldUtils.buildETFF("Gender","gender", gender,defaultGender);
		Map DOBMap   	        = FieldUtils.buildNF("Dob","dob", dob, false);
		Map heightMap  	        = FieldUtils.buildTF("Height","height", height, false);
		Map weightMap      = FieldUtils.buildTF("Weight","weight", weight, false);
		Map DiagnosisrMap             = FieldUtils.buildETFF("Diagnosis","diagnosis",diagnosis, defaultDiagnosisName);
		Map doctorMap             = FieldUtils.buildETFF("Doctor","doctor",doctor, defaultDoctorName);
		Map nurseMap             = FieldUtils.buildETFF("Nurse","nurse",nurse, defaultNurseNameName);
		Map statusMap           	= FieldUtils.buildETFF("Status","status", status,defaultStatus);
		//Map loctionMap           	= FieldUtils.buildETFF("Location","location", location,defaultStatus, false);
		
		
		
	
	
		
		def fieldsList = ["components" : [nameMap,genderMap,DOBMap,heightMap,weightMap,DiagnosisrMap,doctorMap,nurseMap,statusMap]];
		
		return JsonOutput.toJson(fieldsList);
	}
	
	@Override
	public String toString() {
		return name;
	}
	
	def setUpdateMode(boolean updatable) {
		println("Update Mode set to "+updatable)
		updateMode = updatable;
	}
	
}

