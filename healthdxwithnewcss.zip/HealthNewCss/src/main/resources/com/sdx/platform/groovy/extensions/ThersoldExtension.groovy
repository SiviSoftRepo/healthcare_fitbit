package com.sdx.platform.groovy.extensions

import com.sdx.entity.*
import com.sdx.platform.groovy.Basics
import groovy.transform.ToString

import org.springframework.beans.factory.annotation.Autowired
import org.springframework.context.annotation.ComponentScan
import org.springframework.data.mongodb.core.mapping.Document
import com.sdx.platform.groovy.FieldUtils

import org.springframework.context.annotation.ComponentScan


import com.sdx.entity.BaseEntity
import com.sdx.entity.*

import java.util.*;
import groovy.json.JsonOutput



class ThersoldExtensions  extends Thersold implements Basics {

	private boolean updateMode = false;

	def buildFIO(HashMap dbref) {

		//Map useridMap  	      	    = FieldUtils.buildTF("idRep","idRep", idRep, false);
		Map nameMap  	       			 	= FieldUtils.buildTF("Name","name", name, false);
		Map bodyTemperatureMap              = FieldUtils.buildTF("bodyTemperature","bodyTemperature", bodyTemperature, false);
		Map bloodPressureMap   	            = FieldUtils.buildTF("bloodPressure","bloodPressure", bloodPressure, false);
		Map lowerLimitMap  	                = FieldUtils.buildTF("lowerLimit","lowerLimit", lowerLimit, false);
		Map upperLimitMap      			    = FieldUtils.buildTF("upperLimit","upperLimit", upperLimit, false);
		Map normalMap                       = FieldUtils.buildTF("normal","normal", normal, false);
		Map systolicMap                     = FieldUtils.buildTF("systolic","systolic", systolic, false);
		Map diastolicMap                    = FieldUtils.buildTF("diastolic","diastolic", diastolic, false);



		def fieldsList = ["components" : [
				nameMap,
				bodyTemperatureMap,
				bloodPressureMap,
				lowerLimitMap,
				upperLimitMap,
				normalMap,
				systolicMap,
				diastolicMap
			]];

		return JsonOutput.toJson(fieldsList);
	}

	@Override
	public String toString() {
		return name;
	}

	def setUpdateMode(boolean updatable) {
		println("Update Mode set to "+updatable)
		updateMode = updatable;
	}
}