package com.sdx.platform.groovy.extensions


import com.sdx.entity.*;
import com.sdx.platform.groovy.Basics
import groovy.transform.ToString

import org.springframework.beans.factory.annotation.Autowired
import org.springframework.context.annotation.ComponentScan
import org.springframework.data.mongodb.core.mapping.Document
import com.sdx.platform.groovy.FieldUtils

import org.springframework.context.annotation.ComponentScan


import com.sdx.entity.BaseEntity
import com.sdx.entity.*

import java.util.*;
import groovy.json.JsonOutput

class EventDistributorExtension extends EventDistributor implements Basics {

	private boolean updateMode = false;


	def buildFIO(HashMap dbref) {

		ArrayList<Object> patient = dbref.get("patientList");
		ArrayList<Object> vitals = dbref.get("vitalList");
		ArrayList<Object> diagnosis = dbref.get("diagoniseList");
		String result = dbref.get("DefaultResult");
		
		println(result+"I am in groovy");
		


		//Map useridMap  	      	    = FieldUtils.buildTF("idRep","idRep", idRep, false);
		Map patientNameMap  	       		 = FieldUtils.buildETFF("Patient Name","patientName", patient,"" );
		Map diagnosisNameMap           	= FieldUtils.buildETFF("DiagnosisName","diagnosisName", diagnosis,"");
		Map vitalNameMap   	        = FieldUtils.buildETFF("Vital Name","vitalName", vitals,"");
		Map testResultMap  	       		 = FieldUtils.buildTF("Test Result","testResult", testResult, false);
		Map PushResultMap  	       		 = FieldUtils.buildTFF("Push Result","result", result, false);


		def fieldsList = ["components" : [patientNameMap, diagnosisNameMap, vitalNameMap, testResultMap,PushResultMap]];

		return JsonOutput.toJson(fieldsList);
	}

	@Override
	public String toString() {
		return diagnosisName;
	}

	def setUpdateMode(boolean updatable) {
		println("Update Mode set to "+updatable)
		updateMode = updatable;
	}
}